# CodeAlpha_EDA_Books

Task 2 of the CodeAlpha Data Analytics internship: Exploratory Data Analysis.

## Dataset
1,000 books scraped from books.toscrape.com in Task 1 (`data/books_raw.csv`): title, price, rating, availability, url.

## Questions explored
1. Is the data clean (missing values, duplicates, wrong types)?
2. How are prices distributed, and are there outliers?
3. How are ratings distributed?
4. Do higher-priced books get higher ratings?
5. Do budget, mid and premium books differ in rating?
6. Does title length relate to rating?

## Methods
- Cleaning: price text to float, availability to boolean, duplicate removal
- Outlier detection: IQR method
- Statistics: Spearman correlation, Kruskal-Wallis test
- Charts: histogram, count plot, box plots, bar plot, scatter plot, heatmap

## How to run
1. Copy `books_raw.csv` from Task 1 into the `data/` folder.
2. Run:
```bash
pip install -r requirements.txt
jupyter notebook EDA_Books.ipynb
```
3. Run all cells. A cleaned file is saved as `data/books_clean.csv`.

## Key findings
(Add your own findings after running the notebook.)
